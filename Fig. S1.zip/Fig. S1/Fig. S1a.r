library(ggplot2)
library(reshape2)
library(dplyr)
library(readxl)
data<-read_excel("H:/Tidal/R_data/Fig.1b/Fig.1b.xlsx")
data$Type = factor(data$Type, levels=c('Complete','High-quality','Medium-quality','Low-quality','Not-determined'))
ggplot(data, aes(x=Type, y=length),color=Type) + 
  geom_boxplot(outlier.size=0.5,aes(fill=factor(Type))) + 
  theme(axis.text.x=element_text(angle=0,hjust=0.2, vjust=0.5)) +
  theme(legend.position="top")+
  labs(x="",y="Genome size (kb)")+
  theme(axis.line = element_line(color="black"))+
  scale_fill_manual(breaks=c('Complete','High-quality','Medium-quality','Low-quality','Not-determined'),
                    values=c("#696969","#8470FF","#ff9d6f","#7AC5CD","#CFCFCF"))+
  theme_test()+theme(legend.position = 'none')+theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),
                                                     axis.title.x = element_text(size=15),axis.title.y = element_text(size=16),
                                                     axis.text.x = element_text(angle=30,hjust =1,size=14,colour = 'black'),
                                                     axis.text.y=element_text(size=14,colour = 'black'),
                                                     panel.border = element_rect(size=1),
                                                     legend.text = element_text(size=15),
                                                     legend.title = element_text(size=16))
ggsave("Fig. S1A.tiff",width= 4.5,height= 5, path="H:/Tidal/Fig")   
