library(readxl)
library(ggpmisc)
jmz<-read_excel("H:/Tidal/R_data/Fig.1b/Fig.1b.xlsx",col_names = T)
library(ggplot2)
library(RColorBrewer)
library(ggpubr)
ggplot(data = jmz, mapping = aes(x=length,y=RPKG))+
  geom_point(size = 1, alpha = 0.9,shape=19)+
  stat_smooth(color="blue",method = 'lm',se=F,size=0.8,fullrange=T,formula = y ~ x)+   
  theme(axis.line = element_line(color="black"))+
  labs(x="Genome size (kb)",y="Viral normalized abundance")+
  theme(legend.key = element_blank())+
  theme(axis.line = element_line(color=))+
  theme_test()+theme( axis.title.x = element_text(size=16),axis.title.y = element_text(size=16),
                              axis.text.x = element_text(hjust =0.5,size=14,colour = 'black'),
                              axis.text.y=element_text(size=14,colour = 'black'),
                              panel.border = element_rect(size=1),
                              legend.text = element_text(size=14),
                              legend.title = element_blank())+
stat_cor(method = "spearman",aes(label = paste(..rr.label.., ..p.label.., sep = "~`,`~")),
         label.x = )

ggsave("Fig.S1b.tiff",width=5,height=4.7,path="H:/Tidal/Fig")
